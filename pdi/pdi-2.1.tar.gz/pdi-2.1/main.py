#!/usr/bin/env python2
# -*- coding: utf-8 -*-

### Pacman database informer 2.1
### by mangus
### mangus@deprecated.it
###The ARCHLINUX name and logo are recognized trademarks
###See http://www.archlinux.org for acceptable use and restrictions.

import sys
import os
from subprocess import Popen, PIPE
import ConfigParser
from PyQt4 import QtGui, QtCore
from mainform import Ui_MainWindow

CFG_PATH = os.getenv('HOME') + "/.pdirc"   #Config File Path

class MainWindow(QtGui.QMainWindow,Ui_MainWindow):
    def __init__(self,parent=None):
        super(MainWindow, self).__init__(parent)
        self.setupUi(self)
        self.statusbar.showMessage('Pacman database Informer')
        self.lineEdit.backspace()
        self.lineEdit.setPlaceholderText('Insert complete PATH - pacman -Qo')
        self.refresh()
        #signals
        self.pushButton_5.clicked.connect(self.refresh)
        self.pushButton.clicked.connect(self.searchPkg)
        self.actionRefresh.triggered.connect(self.refresh)
        self.comboBox.activated[str].connect(self.listRepo)
        self.connect(self.actionExit, QtCore.SIGNAL("triggered()"), self.quit)
        self.connect(self.lineEdit,QtCore.SIGNAL("returnPressed ()"),self.searchPkg)

    def quit(self):
        QtGui.QApplication.quit()

    def closeEvent(self, event):  ##reimplemented qt function
        if cfg.getboolean("General", "usesystray") == True:
            self.hide()  ##always hide the mainwindow
            event.ignore()
        pass

    def style(self):
        self.textEdit.setStyleSheet("background-image:url('pixmaps/sticker-arch2.png'); "
                                    "background-repeat: no repeat; background-position:center; ")
        self.textEdit_2.setStyleSheet("background-image:url('pixmaps/sticker-arch2.png'); "
                                      "background-repeat: no repeat; background-position:center; ")
        self.textEdit_3.setStyleSheet("background-image:url('pixmaps/sticker-arch2.png'); "
                                      "background-repeat: no repeat; background-position:center; ")
        self.textEdit_4.setStyleSheet("background-image:url('pixmaps/sticker-arch2.png'); "
                                      "background-repeat: no repeat; background-position:center; ")

    def removeStyle(self):
        self.textEdit.setStyleSheet("background-image:url('');")
        self.textEdit_2.setStyleSheet("background-image:url('');")
        self.textEdit_3.setStyleSheet("background-image:url('');")
        self.textEdit_4.setStyleSheet("background-image:url('');")

    def clear(self):
        self.listWidget.clear()
        self.textEdit.clear()
        self.textEdit_2.clear()
        self.textEdit_3.clear()
        self.textEdit_4.clear()
        self.lineEdit.clear()
        self.tabWidget.setCurrentWidget(self.tab_3)
        self.style()

    def refresh(self):
        global repo_list
        repo_list=[]
        repo_list=self.findRepos()
        self.comboBox.addItems(repo_list)
        self.comboBox.insertSeparator((self.comboBox.count())-3)
        self.clear()
        self.comboBox.setCurrentIndex(0)
        self.listRepo('All')

    def listRepo(self,repo):
        self.clear()
        if repo == 'Orphans - pacman -Qdt':
            cmd='pacman -Qdt'
            barstring=' orphans packages'
            self.listPackages(cmd,barstring)
        elif repo == 'Foreign - pacman -Qm':
            cmd='pacman -Qm'
            barstring=' foreign packages'
            self.listPackages(cmd,barstring)
        else:
            if repo == 'Stable - All But Testing and Unstable':
                repos = [i for i in repo_list[1:-3] if 'testing' not in i and 'unstable' not in i]
            elif repo == 'All':
                repos = repo_list[1:-3]
            else:
                repos = [repo]
            for repo in repos:
                cmd='paclist '+ str(repo)
                barstring=' packages'
                self.listPackages(cmd,barstring)

    def listPackages(self,cmd,barstring):
        for i in Popen(cmd,shell=True,stdout=PIPE).stdout:
            item = QtGui.QListWidgetItem(i.strip())
            item.setIcon(QtGui.QIcon('pixmaps/tgz.png'))
            self.listWidget.addItem(item)
        c=self.listWidget.count()
        self.statusbar.showMessage(str(c) + ' ' + barstring)

    def findRepos(self):
        repo_list = ['All', 'Orphans - pacman -Qdt', 'Foreign - pacman -Qm',
                     'Stable - All But Testing and Unstable']
        f = open('/etc/pacman.conf','r')
        for line in f.readlines():
            if line[0] == '[':  ## this may be ugly....
                a = line.strip().strip('[]') # first strip needed for white space
                repo_list.insert(-3, a)
        f.close()
        repo_list.pop(repo_list.index('options'))
        return repo_list

    def on_listWidget_itemClicked(self, item):
        ### first tab info
        # clean and set first tab
        self.removeStyle()
        self.textEdit.clear()
        self.textEdit_2.clear()
        self.textEdit_3.clear()
        self.textEdit_4.clear()
        self.tabWidget.setCurrentWidget(self.tab_3)
        p=str(item.text()).split(" ")[0]
        cmd="pacman -Qi " + p
        a=Popen(cmd,shell=True,stdout=PIPE).stdout.read().decode("utf-8")
        self.textEdit.setText(a)

        ### second tab files
        self.textEdit_2.clear()
        a=self.listWidget.selectedItems()[0]
        p=str(a.text()).split(" ")[0]
        cmd="pacman -Ql " + p
        l=Popen(cmd,shell=True,stdout=PIPE).stdout.read().decode("utf-8")
        self.textEdit_2.setText(l)

        ### third tab scripts
        self.textEdit_3.clear()
        a=self.listWidget.selectedItems()[0]
        p=str(a.text()).split(" ")[0]
        cmd="pacscripts " + p
        run=Popen(cmd,shell=True,stdout=PIPE,stderr=PIPE)
        so=run.stdout.read().decode( "utf-8")
        se=run.stderr.read().decode( "utf-8")
        self.textEdit_3.setText(str(so)+str(se))

        ### fourth tab deps tree
        self.textEdit_4.clear()
        a=self.listWidget.selectedItems()[0]
        p=str(a.text()).split(" ")[0]
        app.setOverrideCursor(QtGui.QCursor(QtCore.Qt.WaitCursor))
        self.statusbar.showMessage('Loading deps tree')
        cmd="pactree " + p
        l=Popen(cmd,shell=True,stdout=PIPE).stdout.read().decode("utf-8")
        self.textEdit_4.setText(l)
        self.statusbar.showMessage('Done')
        app.restoreOverrideCursor()

    def searchPkg(self):
        self.listWidget.clear()
        self.tabWidget.setCurrentWidget(self.tab_3)
        self.textEdit.clear()
        a=self.lineEdit.displayText().toUtf8()
        b=str(a)
        if not b:
            self.textEdit.clear()
            self.removeStyle()
            self.textEdit.setText('No file specified.')
            return
        cmd="pacman -Qo " + str(a)
        app.setOverrideCursor(QtGui.QCursor(QtCore.Qt.WaitCursor))
        a=Popen(cmd,shell=True,stdout=PIPE).stdout.readlines()
        if not a:
            self.textEdit.clear()
            self.removeStyle()
            self.textEdit.setText('No such file or directory.')
            app.restoreOverrideCursor()
            return

        for l in Popen(cmd,shell=True,stdout=PIPE).stdout.readlines():
            r=l.decode( "utf-8")
            print r
            item = QtGui.QListWidgetItem(r.strip().split(" ")[4] + ' ' +r.strip().split(" ")[5])
            item.setIcon(QtGui.QIcon('pixmaps/tgz.png'))
            self.listWidget.addItem(item)
        self.statusbar.showMessage('Done.')
        app.restoreOverrideCursor()

    @QtCore.pyqtSignature("")
    def on_actionUse_Systray_triggered(self):
        cfgfile = open(CFG_PATH,'w')
        if self.actionUse_Systray.isChecked():
            print 'Use Systray set to True'
            cfg.set('General','usesystray',True)
            cfg.write(cfgfile)
            self.actionStart_minimized.setEnabled(True)
            trayIcon.show()
        else:
            print 'Use Systray set to False'
            cfg.set('General','usesystray',False)
            cfg.set('General','startminimized',False)
            cfg.write(cfgfile)
            self.actionStart_minimized.setEnabled(False)
            trayIcon.hide()
        cfgfile.close()
        cfg.read(CFG_PATH)

    @QtCore.pyqtSignature("")
    def on_actionStart_minimized_triggered(self):
        cfgfile = open(CFG_PATH,'w')
        if self.actionStart_minimized.isChecked():
            print 'Start minimized set to True'
            cfg.set('General','startminimized',True)
            cfg.write(cfgfile)
        else:
            print 'Start minimized set to False'
            cfg.set('General','startminimized',False)
            cfg.write(cfgfile)
        cfgfile.close()
        cfg.read(CFG_PATH)

    @QtCore.pyqtSlot()
    def on_actionAbout_triggered(self):
        QtGui.QMessageBox.about(self ,'Pacman database Informer' , 'Pacman database Informer 2.1 by mangus \n \n'
                                      'A little tool for little queries to the pacman database \n'
                                      'mail to: mangus@deprecated.it \n \n'
                                      'Thanks to EnvoyRising for feedback and patches \n \n'
                                      'The ARCHLINUX name and logo are recognized trademarks \n'
                                      'See http://www.archlinux.org/ for acceptable use and restrictions.')

    @QtCore.pyqtSlot()
    def on_actionAbout_Qt_triggered(self):
        QtGui.QMessageBox.aboutQt(self)

    def on_actionArchlinux_org_triggered(self):
        QtGui.QDesktopServices().openUrl(QtCore.QUrl('http://www.archlinux.org'))


class SystemTrayIcon(QtGui.QSystemTrayIcon):
    def __init__(self, icon, parent=None):
        QtGui.QSystemTrayIcon.__init__(self, icon, parent)
        menu = QtGui.QMenu(parent)
        # Actions
        self.actionQuit= QtGui.QAction(QtGui.QIcon('pixmaps/application-exit.png'),"Exit", self)
        menu.addAction(self.actionQuit)
        # signal of quit, can't get it to work in 'python way' dunno why
        self.connect(self.actionQuit, QtCore.SIGNAL("triggered()"), self.quit)
        # signal for restoring mainwindow,convoluted but works
        traySignal = "activated(QSystemTrayIcon::ActivationReason)"
        QtCore.QObject.connect(self, QtCore.SIGNAL(traySignal), self.icon_activated)
        # Create Menu
        self.setContextMenu(menu)

    def quit(self):
        QtGui.QApplication.quit()

    def icon_activated(self, reason):
        if reason == QtGui.QSystemTrayIcon.Trigger:
            mainwindow.show()

def main():
    global app
    global mainwindow
    global trayIcon
    app = QtGui.QApplication(sys.argv)
    mainwindow=MainWindow()
    # TrayIcon
    if QtGui.QSystemTrayIcon.isSystemTrayAvailable():
        w = QtGui.QWidget()
        icon = QtGui.QIcon("pixmaps/archlinux-icon-crystal-64.svg")
        trayIcon = SystemTrayIcon(icon, w)
        trayIcon.setToolTip("pdi - pacman database informer")
        if cfg.getboolean("General", "usesystray") == True:
            mainwindow.actionUse_Systray.setChecked(True)
            trayIcon.show()
        else:
            mainwindow.actionUse_Systray.setChecked(False)
            mainwindow.actionStart_minimized.setChecked(False)
            mainwindow.actionStart_minimized.setEnabled(False)
            trayIcon.hide()

    if cfg.getboolean("General", "startminimized") == False:
        mainwindow.actionStart_minimized.setChecked(False)
        mainwindow.show()
    else:
        mainwindow.actionStart_minimized.setChecked(True)
        mainwindow.hide()

    sys.exit(app.exec_())

def Ini():
    global cfg
    cfg = ConfigParser.ConfigParser()
    if not os.path.exists(CFG_PATH):
        print 'Config file not present, creating a default one in ' + CFG_PATH
        cfgfile = open(CFG_PATH,'w')
        cfg.add_section('General')
        cfg.set('General','usesystray',True) ###defaults
        cfg.set('General','startminimized',False)
        cfg.write(cfgfile)
        cfgfile.close()
    cfg.read(CFG_PATH)

if __name__ == "__main__":
    Ini()
    main()