#!/usr/bin/env python2
# -*- coding: utf-8 -*-

### Pacman database informer 2.0.1
### by mangus
### mangus@deprecated.it
###The ARCHLINUX name and logo are recognized trademarks
###See http://www.archlinux.org for acceptable use and restrictions.

import sys
import os
import subprocess
from PyQt4 import QtGui, QtCore
from mainform import Ui_MainWindow

class MainWindow(QtGui.QMainWindow,Ui_MainWindow):
	def __init__(self,parent=None):
		  super(MainWindow, self).__init__(parent)
		  self.setupUi(self)
		  self.statusbar.showMessage('Pacman database Informer')
		  self.lineEdit.backspace() ##active bs key usage - remember 4.7 setPlaceholder when pyqt will support this in next versions
		  self.findRepos()
		  self.style()
		  self.listAll()
		#signals
		  self.pushButton_5.clicked.connect(self.clearAll)
		  self.pushButton.clicked.connect(self.searchPkg)
		  self.actionRefresh.triggered.connect(self.clearAll)
		  self.comboBox.activated[str].connect(self.listRepo) ###dunno how to pythonize this
		  self.connect(self.actionExit, QtCore.SIGNAL("triggered()"), self.quit)
		  self.connect(self.lineEdit,QtCore.SIGNAL("returnPressed ()"),self.searchPkg)

	def quit(self):
		  QtGui.QApplication.quit()

	def closeEvent(self, event):  ##reimplemented qt function
		  self.hide()  ##always hide the mainwindow
		  event.ignore()

	def style(self):
		  self.textEdit.setStyleSheet ("background-image:url('pixmaps/sticker-arch2.png'); \
						    background-repeat: no repeat; background-position:center; \
						  ")
		  self.textEdit_2.setStyleSheet ("background-image:url('pixmaps/sticker-arch2.png'); \
						    background-repeat: no repeat; background-position:center; \
						  ")
		  self.textEdit_3.setStyleSheet ("background-image:url('pixmaps/sticker-arch2.png'); \
						    background-repeat: no repeat; background-position:center; \
						  ")
		  self.textEdit_4.setStyleSheet ("background-image:url('pixmaps/sticker-arch2.png'); \
						    background-repeat: no repeat; background-position:center; \
						  ")


	def removeStyle(self):
		  self.textEdit.setStyleSheet ("background-image:url('');")
		  self.textEdit_2.setStyleSheet ("background-image:url('');")
		  self.textEdit_3.setStyleSheet ("background-image:url('');")
		  self.textEdit_4.setStyleSheet ("background-image:url('');")

	def clearAll(self):
		  self.listWidget.clear()
		  self.textEdit.clear()
		  self.textEdit_2.clear()
		  self.textEdit_3.clear()
		  self.textEdit_4.clear()
		  self.lineEdit.clear()
		  self.findRepos()
		  self.comboBox.setCurrentIndex(0)
		  self.tabWidget.setCurrentWidget(self.tab_3)
		  self.style()
		  self.listAll()

	def listAll(self):
		  self.listWidget.clear()
		  for i in os.popen("pacman -Q","r"):
		    item = QtGui.QListWidgetItem(i.strip())
		    item.setIcon(QtGui.QIcon('pixmaps/tgz.png'))
		    self.listWidget.addItem(item)
		  c=self.listWidget.count()
		  self.statusbar.showMessage(str(c) + ' installed packages')

	def listRepo(self,repo):
		  self.listWidget.clear()
		  self.textEdit.clear()
		  self.style()
		  self.textEdit_2.clear()
		  self.textEdit_3.clear()
		  self.textEdit_4.clear()
		  if str(repo) == 'All':
		     self.listAll()
		     return
		  if str(repo) == 'Orphans - pacman -Qdt':
		      self.listOrphans()
		      return
		  if str(repo) == 'Foreign - pacman -Qm':
		      self.listForeign()
		      return
		  for i in os.popen("paclist "+ str(repo),"r"):
		     item = QtGui.QListWidgetItem(i.strip())
		     item.setIcon(QtGui.QIcon('pixmaps/tgz.png'))
		     self.listWidget.addItem(item)
		  c=self.listWidget.count()
		  self.statusbar.showMessage(str(c) + ' ' + str(repo) +' packages')

	def findRepos(self):
		  qlist= QtCore.QStringList('All')
		  f = open('/etc/pacman.conf','r')
		  for line in f.readlines():
		     if line[0] == '[':  ## this may be ugly....
			 a=line.split(' ')[0].rstrip("\n")[1:-1]
		         qlist.append(a)
		  f.close()
		  qlist.removeAt(1)  ###removes '[options]' from pacman.conf parsed with the repos
		  qlist.append('Orphans - pacman -Qdt')
		  qlist.append('Foreign - pacman -Qm')
		  self.comboBox.addItems(qlist)
		  self.comboBox.insertSeparator((self.comboBox.count())-2)

	def on_listWidget_itemClicked(self, item):
	    ### first tab info
		 # clean and set first tab
		  self.removeStyle()
		  self.textEdit.clear()
		  self.textEdit_2.clear()
		  self.textEdit_3.clear()
		  self.textEdit_4.clear()
		  self.tabWidget.setCurrentWidget(self.tab_3)

	          p=str(item.text()).split(" ")[0]
	          cmd="pacman -Qi " + p
	          a=os.popen(cmd).read().decode("utf-8")
		  self.textEdit.setText(a)

	    ### second tab files
		  self.textEdit_2.clear()
		  a=self.listWidget.selectedItems()[0]
		  p=str(a.text()).split(" ")[0]
		  cmd="pacman -Ql " + p
		  l=os.popen(cmd).read()
		  self.textEdit_2.setText(l)

	    ### third tab scripts
		  self.textEdit_3.clear()
		  a=self.listWidget.selectedItems()[0]
		  p=str(a.text()).split(" ")[0]
		  cmd="pacscripts " + p
		  r = subprocess.Popen(cmd, shell=True ,stdout=subprocess.PIPE, stdin=subprocess.PIPE,  stderr=subprocess.PIPE)
		  o=r.stdout.read().decode( "utf-8")
		  u=r.stderr.read().decode( "utf-8")
		  self.textEdit_3.setText(str(o)+str(u))

	    ### fourth tab deps tree
		  self.textEdit_4.clear()
		  a=self.listWidget.selectedItems()[0]
		  p=str(a.text()).split(" ")[0]
		  app.setOverrideCursor(QtGui.QCursor(QtCore.Qt.WaitCursor))
		  self.statusbar.showMessage('Loading deps tree')
		  cmd="pactree " + p
		  l=os.popen(cmd).read()
		  self.textEdit_4.setText(l)
		  self.statusbar.showMessage('Done')
		  app.restoreOverrideCursor()

	def listOrphans(self):
		  self.listWidget.clear()
		  for i in os.popen("pacman -Qdt","r"):
		     item = QtGui.QListWidgetItem(i.strip())
		     item.setIcon(QtGui.QIcon('pixmaps/tgz.png'))
		     self.listWidget.addItem(item)
		  c=self.listWidget.count()
		  self.statusbar.showMessage(str(c) + ' orphans packages')

	def listForeign(self):
		  self.listWidget.clear()
		  for i in os.popen("pacman -Qm","r"):
		     item = QtGui.QListWidgetItem(i.strip())
		     item.setIcon(QtGui.QIcon('pixmaps/tgz.png'))
		     self.listWidget.addItem(item)
		  c=self.listWidget.count()
		  self.statusbar.showMessage(str(c) + ' foreign packages')

	def searchPkg(self):
		  self.listWidget.clear()
		  self.tabWidget.setCurrentWidget(self.tab_3)
		  self.textEdit.clear()
		  a=self.lineEdit.displayText().toUtf8()
		  b=str(a)
		  if not b:
		    self.textEdit.clear()
		    self.removeStyle()
		    self.textEdit.setText('No file specified.')
		    return
		  cmd="pacman -Qo " + str(a)
		  app.setOverrideCursor(QtGui.QCursor(QtCore.Qt.WaitCursor))
		  a=os.popen(cmd).readlines()
		  if not a:
		    self.textEdit.clear()
		    self.removeStyle()
		    self.textEdit.setText('No such file or directory.')
		    app.restoreOverrideCursor()
		    return

		  for l in os.popen(cmd):
		    r=l.decode( "utf-8")
		    item = QtGui.QListWidgetItem(r.strip().split(" ")[4] + ' ' +r.strip().split(" ")[5])
		    item.setIcon(QtGui.QIcon('pixmaps/tgz.png'))
		    self.listWidget.addItem(item)
		  self.statusbar.showMessage('Done.')
		  app.restoreOverrideCursor()

	@QtCore.pyqtSlot()
	def on_actionAbout_triggered(self):
		  QtGui.QMessageBox.about(self ,"Pacman database Informer" , 'Pacman database Informer 2.0.1 by mangus \n \n'
									     'A little tool for little queries to the pacman database \n'
									     'mangus@deprecated.it \n \n The ARCHLINUX name and'
									     'logo are recognized trademarks \n'
									     'See http://www.archlinux.org/ for acceptable use and restrictions.')

	@QtCore.pyqtSlot()
	def on_actionAbout_Qt_triggered(self):
		  QtGui.QMessageBox.aboutQt(self)

	def on_actionArchlinux_org_triggered(self):
		  QtGui.QDesktopServices().openUrl(QtCore.QUrl('http://www.archlinux.org'))

class SystemTrayIcon(QtGui.QSystemTrayIcon):
    def __init__(self, icon, parent=None):
        QtGui.QSystemTrayIcon.__init__(self, icon, parent)
        menu = QtGui.QMenu(parent)
        # Actions
        self.actionQuit= QtGui.QAction(QtGui.QIcon('pixmaps/application-exit.png'),"Exit", self)
        menu.addAction(self.actionQuit)
        # Connect menu with signals
        self.connect(self.actionQuit, QtCore.SIGNAL("triggered()"), self.quit)
        # Other signals
        traySignal = "activated(QSystemTrayIcon::ActivationReason)"
        QtCore.QObject.connect(self, QtCore.SIGNAL(traySignal), self.icon_activated)
        # Create Menu
        self.setContextMenu(menu)

    def quit(self):
        QtGui.QApplication.quit()

    def icon_activated(self, reason):
        if reason == QtGui.QSystemTrayIcon.Trigger:
            mainwindow.show()

def main():
    global app
    app = QtGui.QApplication(sys.argv)
    # TrayIcon
    if QtGui.QSystemTrayIcon.isSystemTrayAvailable():
	w = QtGui.QWidget()
	icon = QtGui.QIcon("pixmaps/archlinux-icon-crystal-64.svg")
	trayIcon = SystemTrayIcon(icon, w)
	trayIcon.show()
	trayIcon.setToolTip("pdi - pacman database informer")
    # Main Window
    global mainwindow
    mainwindow=MainWindow()
    mainwindow.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()